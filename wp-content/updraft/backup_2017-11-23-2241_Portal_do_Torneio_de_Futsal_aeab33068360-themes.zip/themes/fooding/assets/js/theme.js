/**
* Parallax Section
*/
( function() {
    jQuery('.site-header').parallax();
})();
